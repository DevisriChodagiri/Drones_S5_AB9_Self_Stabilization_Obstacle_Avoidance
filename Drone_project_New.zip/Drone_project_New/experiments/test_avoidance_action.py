import sys
import os

# -----------------------------------------
# ADD PROJECT ROOT TO PYTHON PATH
# -----------------------------------------

sys.path.append(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)

from navigation.obstacle_avoidance import ObstacleAvoidance


def main():

    print("Starting avoidance action test...")

    # -----------------------------------------
    # CREATE AVOIDANCE SYSTEM
    # -----------------------------------------

    avoidance = ObstacleAvoidance(
        safe_distance=1.5,
        danger_distance=0.8,
        warning_ttc=5.0,
        danger_ttc=2.0
    )

    # -----------------------------------------
    # TEST CASES
    # -----------------------------------------

    test_cases = [

        # Distance, Closing Speed, TTC
        (4.0, 0.5, 8.0),
        (3.0, 0.8, 4.0),
        (2.0, 1.0, 2.5),
        (2.0, 1.2, 1.7),
        (0.7, 1.0, 0.7),
        (4.0, 2.0, 2.0)
    ]

    print(
        "\nDistance\tClosing\tTTC\tAction"
    )

    print(
        "--------------------------------------------"
    )

    # -----------------------------------------
    # TEST EACH CASE
    # -----------------------------------------

    for distance, closing_speed, ttc in test_cases:

        action = avoidance.decide_action(
            distance,
            closing_speed,
            ttc
        )

        print(
            f"{distance:.2f}\t\t"
            f"{closing_speed:.2f}\t"
            f"{ttc:.2f}\t"
            f"{action}"
        )

    print(
        "\nAvoidance action test completed."
    )


if __name__ == "__main__":
    main()