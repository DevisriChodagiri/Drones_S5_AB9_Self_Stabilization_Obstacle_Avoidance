import sys
import os
import pybullet as p

# -----------------------------------------
# ADD PROJECT ROOT TO PYTHON PATH
# -----------------------------------------

sys.path.append(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)

from simulation.physics import PhysicsWorld
from simulation.drone import Drone
from simulation.environment import Environment
from sensors.distance_sensor import DistanceSensor


def main():

    print("Starting closing speed test...")

    # -----------------------------------------
    # 1. CREATE PHYSICS WORLD
    # -----------------------------------------

    physics = PhysicsWorld()

    # -----------------------------------------
    # 2. CREATE DRONE
    # -----------------------------------------

    drone = Drone()

    # -----------------------------------------
    # 3. CREATE ENVIRONMENT
    # -----------------------------------------

    environment = Environment()

    # -----------------------------------------
    # 4. CREATE OBSTACLE
    # -----------------------------------------

    obstacle_position = [5.0, 0.0, 1.0]

    obstacle_id = environment.add_static_obstacle(
        position=obstacle_position,
        size=[0.2, 0.2, 0.2]
    )

    # -----------------------------------------
    # 5. CREATE DISTANCE SENSOR
    # -----------------------------------------

    sensor = DistanceSensor(
        drone_id=drone.drone_id,
        max_distance=10.0
    )

    # -----------------------------------------
    # 6. MOVEMENT PARAMETERS
    # -----------------------------------------

    velocity = -0.5

    acceleration = -0.2

    dt = 0.1

    # -----------------------------------------
    # 7. PREVIOUS DISTANCE
    # -----------------------------------------

    previous_distance = (
        sensor.get_distance_to_obstacle(
            obstacle_id
        )
    )

    print(
        "\nTime\tDistance\tVelocity\tClosing Speed"
    )

    print(
        "----------------------------------------------------"
    )

    # -----------------------------------------
    # 8. MOVE OBSTACLE
    # -----------------------------------------

    for step in range(20):

        time = step * dt

        # -------------------------------------
        # GET CURRENT POSITION
        # -------------------------------------

        obstacle_position, orientation = (
            p.getBasePositionAndOrientation(
                obstacle_id
            )
        )

        current_x = obstacle_position[0]

        # -------------------------------------
        # UPDATE VELOCITY
        #
        # v_new = v_old + a * dt
        # -------------------------------------

        velocity = (
            velocity +
            acceleration * dt
        )

        # -------------------------------------
        # UPDATE POSITION
        #
        # x_new = x_old + v * dt
        # -------------------------------------

        new_x = (
            current_x +
            velocity * dt
        )

        # -------------------------------------
        # UPDATE OBSTACLE POSITION
        # -------------------------------------

        p.resetBasePositionAndOrientation(
            obstacle_id,
            [new_x, 0.0, 1.0],
            orientation
        )

        # -------------------------------------
        # MEASURE CURRENT DISTANCE
        # -------------------------------------

        current_distance = (
            sensor.get_distance_to_obstacle(
                obstacle_id
            )
        )

        # -------------------------------------
        # CALCULATE CLOSING SPEED
        #
        # Vclosing =
        # (Dprevious - Dcurrent) / dt
        # -------------------------------------

        closing_speed = (
            previous_distance -
            current_distance
        ) / dt

        # -------------------------------------
        # DISPLAY VALUES
        # -------------------------------------

        print(
            f"{time:.1f}\t"
            f"{current_distance:.2f}\t\t"
            f"{velocity:.2f}\t\t"
            f"{closing_speed:.2f}"
        )

        # -------------------------------------
        # CURRENT BECOMES PREVIOUS
        # -------------------------------------

        previous_distance = current_distance

        # -------------------------------------
        # STEP PHYSICS
        # -------------------------------------

        physics.step()

    # -----------------------------------------
    # 9. CLOSE SIMULATION
    # -----------------------------------------

    physics.close()

    print(
        "\nClosing speed test completed."
    )


if __name__ == "__main__":
    main()