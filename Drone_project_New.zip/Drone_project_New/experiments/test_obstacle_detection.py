import sys
import os

# -----------------------------------------
# ADD PROJECT ROOT TO PYTHON PATH
# -----------------------------------------

sys.path.append(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)

from simulation.physics import PhysicsWorld
from simulation.drone import Drone
from simulation.environment import Environment
from sensors.distance_sensor import DistanceSensor
from navigation.obstacle_avoidance import ObstacleAvoidance


def main():

    print("Starting obstacle detection integration test...")

    # -----------------------------------------
    # 1. CREATE PHYSICS WORLD
    # -----------------------------------------

    physics = PhysicsWorld()

    # -----------------------------------------
    # 2. CREATE DRONE
    # -----------------------------------------

    drone = Drone()

    # -----------------------------------------
    # 3. CREATE ENVIRONMENT
    # -----------------------------------------

    environment = Environment()

    # -----------------------------------------
    # 4. CREATE DISTANCE SENSOR
    # -----------------------------------------

    sensor = DistanceSensor(
        drone_id=drone.drone_id,
        max_distance=10.0
    )

    # -----------------------------------------
    # 5. CREATE OBSTACLE AVOIDANCE SYSTEM
    # -----------------------------------------

    avoidance = ObstacleAvoidance(
        safe_distance=1.5,
        danger_distance=0.8
    )

    # -----------------------------------------
    # 6. TEST DIFFERENT OBSTACLE POSITIONS
    # -----------------------------------------
    #
    # Drone position:
    # (0, 0, 1)
    #
    # Obstacles are placed along the X axis.
    # -----------------------------------------

    obstacle_positions = [
        [3.0, 0.0, 1.0],
        [2.0, 0.0, 1.0],
        [1.2, 0.0, 1.0],
        [0.5, 0.0, 1.0]
    ]

    print("\nDistance\tDecision")
    print("---------------------------")

    # -----------------------------------------
    # 7. TEST EACH OBSTACLE POSITION
    # -----------------------------------------

    for position in obstacle_positions:

        # Create obstacle
        obstacle_id = environment.add_static_obstacle(
            position=position,
            size=[0.2, 0.2, 0.2]
        )

        # -------------------------------------
        # MEASURE DISTANCE
        # -------------------------------------

        distance = sensor.get_distance_to_obstacle(
            obstacle_id
        )

        # -------------------------------------
        # CLASSIFY DISTANCE
        # -------------------------------------

        decision = avoidance.check_distance(
            distance
        )

        # -------------------------------------
        # DISPLAY RESULT
        # -------------------------------------

        print(
            f"{distance:.2f} m\t\t{decision}"
        )

    # -----------------------------------------
    # 8. CLOSE SIMULATION
    # -----------------------------------------

    physics.close()

    print(
        "\nObstacle detection integration "
        "test completed."
    )


if __name__ == "__main__":
    main()