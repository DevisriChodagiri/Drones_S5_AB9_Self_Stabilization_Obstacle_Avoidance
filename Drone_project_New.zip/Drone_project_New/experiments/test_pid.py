import sys
import os

# ---------------------------------------------------------
# ADD PROJECT ROOT TO PYTHON PATH
# ---------------------------------------------------------

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


# ---------------------------------------------------------
# IMPORT PID CONTROLLER
# ---------------------------------------------------------

from control.pid_controller import PIDController


# ---------------------------------------------------------
# CREATE PID CONTROLLER
# ---------------------------------------------------------

pid = PIDController(
    kp=0.8,
    ki=0.1,
    kd=0.05
)


# ---------------------------------------------------------
# SIMULATION SETTINGS
# ---------------------------------------------------------

dt = 0.02

desired_roll = 0.0

# Start with a large disturbance
actual_roll = 10.0


# ---------------------------------------------------------
# HEADER
# ---------------------------------------------------------

print("\n==============================================")
print("        PID STABILIZATION TEST")
print("==============================================\n")

print(
    "Time\tDesired\tActual\tError\tP\tI\tD\tPID"
)

print("-" * 75)


# ---------------------------------------------------------
# SIMULATE ROLL CORRECTION
# ---------------------------------------------------------

for step in range(50):

    time_value = step * dt


    # ---------------------------------------------
    # CALCULATE PID
    # ---------------------------------------------

    output, proportional, integral, derivative = (
        pid.calculate(
            desired_roll,
            actual_roll,
            dt
        )
    )


    # ---------------------------------------------
    # SIMULATE EFFECT OF PID
    #
    # The PID correction pushes the roll
    # toward the desired value.
    # ---------------------------------------------

    actual_roll = actual_roll + output * dt


    # ---------------------------------------------
    # CALCULATE ERROR
    # ---------------------------------------------

    error = desired_roll - actual_roll


    # ---------------------------------------------
    # PRINT RESULTS
    # ---------------------------------------------

    print(
        f"{time_value:.2f}\t"
        f"{desired_roll:.2f}\t"
        f"{actual_roll:.2f}\t"
        f"{error:.2f}\t"
        f"{proportional:.2f}\t"
        f"{integral:.2f}\t"
        f"{derivative:.2f}\t"
        f"{output:.2f}"
    )


# ---------------------------------------------------------
# COMPLETION
# ---------------------------------------------------------

print("\n==============================================")
print("PID test completed.")
print("==============================================\n")