import sys
import os

# -----------------------------------------
# ADD PROJECT ROOT TO PYTHON PATH
# -----------------------------------------

sys.path.append(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)

from navigation.risk_estimator import RiskEstimator


def main():

    print("Starting risk estimator test...")

    # -----------------------------------------
    # CREATE RISK ESTIMATOR
    # -----------------------------------------

    risk_estimator = RiskEstimator(
        warning_ttc=5.0,
        danger_ttc=2.0,
        danger_distance=0.8
    )

    # -----------------------------------------
    # TEST CASES
    # -----------------------------------------

    test_cases = [

        # Distance, Closing Speed, TTC
        (4.0, 0.5, 8.0),
        (3.0, 0.8, 3.75),
        (1.0, 2.0, 0.5),
        (0.5, 1.0, 0.5),
        (2.0, 2.0, 1.0),
        (4.0, 2.0, 2.0)
    ]

    print(
        "\nDistance\tClosing Speed\tTTC\tRisk"
    )

    print(
        "------------------------------------------------"
    )

    # -----------------------------------------
    # TEST EACH CASE
    # -----------------------------------------

    for distance, closing_speed, ttc in test_cases:

        risk = risk_estimator.calculate_risk(
            distance,
            closing_speed,
            ttc
        )

        print(
            f"{distance:.2f}\t\t"
            f"{closing_speed:.2f}\t\t"
            f"{ttc:.2f}\t"
            f"{risk}"
        )

    print(
        "\nRisk estimator test completed."
    )


if __name__ == "__main__":
    main()