import sys
import os
import time

# -----------------------------------------
# ADD PROJECT ROOT TO PYTHON PATH
# -----------------------------------------

sys.path.append(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)

from simulation.physics import PhysicsWorld
from simulation.drone import Drone
from simulation.environment import Environment
from sensors.distance_sensor import DistanceSensor


def main():

    print("Starting distance sensor test...")

    # -----------------------------------------
    # 1. CREATE PHYSICS WORLD
    # -----------------------------------------

    physics = PhysicsWorld()

    # -----------------------------------------
    # 2. CREATE DRONE
    # -----------------------------------------

    drone = Drone()

    # -----------------------------------------
    # 3. CREATE ENVIRONMENT
    # -----------------------------------------

    environment = Environment()

    # -----------------------------------------
    # 4. CREATE STATIC OBSTACLE
    # -----------------------------------------

    obstacle_id = environment.add_static_obstacle(
        position=[3.0, 0.0, 1.0],
        size=[0.5, 0.5, 0.5]
    )

    # -----------------------------------------
    # 5. CREATE DISTANCE SENSOR
    # -----------------------------------------

    sensor = DistanceSensor(
        drone_id=drone.drone_id,
        max_distance=10.0
    )

    # -----------------------------------------
    # 6. GET INITIAL DISTANCE
    # -----------------------------------------

    distance = sensor.get_distance_to_obstacle(
        obstacle_id
    )

    print("\nDrone position:")
    print(drone.get_position())

    print("\nObstacle position:")
    print("[3.0, 0.0, 1.0]")

    print("\nMeasured distance:")
    print(round(distance, 4), "meters")

    # -----------------------------------------
    # 7. EXPECTED DISTANCE
    # -----------------------------------------
    #
    # Drone:
    # (0, 0, 1)
    #
    # Obstacle:
    # (3, 0, 1)
    #
    # Distance:
    #
    # sqrt((3-0)^2 + (0-0)^2 + (1-1)^2)
    #
    # = sqrt(9)
    #
    # = 3 meters
    # -----------------------------------------

    expected_distance = 3.0

    print("\nExpected distance:")
    print(expected_distance, "meters")

    # -----------------------------------------
    # 8. CHECK RESULT
    # -----------------------------------------

    difference = (
        distance - expected_distance
    )

    if difference < 0:
        difference = -difference

    if difference < 0.001:

        print(
            "\nPASS: Distance sensor is "
            "working correctly."
        )

    else:

        print(
            "\nFAIL: Distance measurement "
            "is incorrect."
        )

    # -----------------------------------------
    # 9. CLOSE PHYSICS
    # -----------------------------------------

    physics.close()

    print("\nDistance sensor test completed.")


if __name__ == "__main__":
    main()