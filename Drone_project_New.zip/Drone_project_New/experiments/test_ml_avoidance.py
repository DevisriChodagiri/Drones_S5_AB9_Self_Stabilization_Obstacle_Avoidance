import sys
import os
import pickle
import pandas as pd

sys.path.append(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)

from navigation.decision_controller import DecisionController


def calculate_ttc(distance, closing_speed):

    if closing_speed > 0:
        return distance / closing_speed

    return float("inf")


def main():

    print("Starting ML + avoidance integration test...")

    # ------------------------------------------------
    # 1. LOAD ML MODEL
    # ------------------------------------------------

    model_path = os.path.join(
        "results",
        "risk_model.pkl"
    )

    scaler_path = os.path.join(
        "results",
        "scaler.pkl"
    )

    with open(model_path, "rb") as file:
        model = pickle.load(file)

    with open(scaler_path, "rb") as file:
        scaler = pickle.load(file)

    print("ML model loaded.")
    print("Scaler loaded.")

    # ------------------------------------------------
    # 2. CREATE DECISION CONTROLLER
    # ------------------------------------------------

    controller = DecisionController()

    # ------------------------------------------------
    # 3. INITIAL CONDITIONS
    # ------------------------------------------------

    distance = 5.0

    closing_speed = 0.5

    roll = 5.0

    pitch = 4.0

    dt = 0.1

    drone_speed = 0.08

    print(
        "\nTime\tDistance\tClosing\tTTC\tRisk\t\tAction\t\tDrone Speed"
    )

    print(
        "--------------------------------------------------------------------------"
    )

    # ------------------------------------------------
    # 4. SIMULATION LOOP
    # ------------------------------------------------

    for step in range(100):

        time_value = step * dt

        # Calculate TTC
        ttc = calculate_ttc(
            distance,
            closing_speed
        )

        # ------------------------------------------------
        # CREATE INPUT FOR ML MODEL
        # ------------------------------------------------

        input_data = pd.DataFrame(
            [[
                distance,
                closing_speed,
                ttc,
                roll,
                pitch
            ]],
            columns=[
                "Distance",
                "ClosingSpeed",
                "TTC",
                "Roll",
                "Pitch"
            ]
        )

        # ------------------------------------------------
        # SCALE INPUT
        # ------------------------------------------------

        input_scaled = scaler.transform(
            input_data
        )

        # ------------------------------------------------
        # ML PREDICTION
        # ------------------------------------------------

        prediction = model.predict(
            input_scaled
        )

        risk = prediction[0]

        # ------------------------------------------------
        # DECISION
        # ------------------------------------------------

        action = controller.decide(
            risk,
            distance,
            closing_speed,
            ttc
        )

        # ------------------------------------------------
        # MOVEMENT CONTROL
        # ------------------------------------------------

        if action == "CONTINUE":

            drone_speed = 0.08

        elif action == "SLOW_DOWN":

            drone_speed = 0.03

        elif action == "AVOID":

            drone_speed = 0.0

        else:

            drone_speed = 0.0

        # ------------------------------------------------
        # DISPLAY
        # ------------------------------------------------

        if step % 5 == 0:

            if ttc == float("inf"):
                ttc_text = "INF"
            else:
                ttc_text = f"{ttc:.2f}"

            print(
                f"{time_value:.1f}\t"
                f"{distance:.2f}\t\t"
                f"{closing_speed:.2f}\t"
                f"{ttc_text}\t"
                f"{risk}\t"
                f"{action}\t"
                f"{drone_speed:.2f}"
            )

        # ------------------------------------------------
        # UPDATE DISTANCE
        # ------------------------------------------------

        distance = (
            distance
            - closing_speed * dt
        )

        # Simulate an approaching obstacle
        closing_speed = (
            closing_speed
            + 0.05
        )

        # Stop when danger occurs
        if action == "AVOID":

            print(
                "\nDANGER detected by ML model."
            )

            print(
                "Drone stopped forward movement."
            )

            print(
                "AVOID action activated."
            )

            break

    print(
        "\nML + avoidance integration test completed."
    )


if __name__ == "__main__":
    main()