import sys
import os
import math

# -----------------------------------------
# ADD PROJECT ROOT TO PYTHON PATH
# -----------------------------------------

sys.path.append(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)

import pybullet as p

from simulation.physics import PhysicsWorld
from simulation.drone import Drone
from sensors.imu import IMU
from control.attitude_controller import AttitudeController
from control.motor_mixer import MotorMixer


def main():

    print("Starting stabilization test...")

    # -----------------------------------------
    # 1. CREATE PHYSICS WORLD
    # -----------------------------------------

    physics = PhysicsWorld()

    # -----------------------------------------
    # 2. CREATE DRONE
    # -----------------------------------------

    drone = Drone()

    # -----------------------------------------
    # 3. CREATE IMU
    # -----------------------------------------

    imu = IMU(drone.drone_id)

    # -----------------------------------------
    # 4. CREATE ATTITUDE CONTROLLER
    # -----------------------------------------

    controller = AttitudeController()

    # -----------------------------------------
    # 5. CREATE MOTOR MIXER
    # -----------------------------------------

    mixer = MotorMixer(max_thrust=5.0)

    # -----------------------------------------
    # 6. SIMULATION SETTINGS
    # -----------------------------------------

    dt = physics.time_step

    # Desired orientation
    desired_roll = 0.0
    desired_pitch = 0.0

    # -----------------------------------------
    # 7. INITIAL DRONE ORIENTATION
    # -----------------------------------------
    # We intentionally disturb the drone.
    #
    # Initial Roll  = 10 degrees
    # Initial Pitch = 10 degrees
    #
    # Desired Roll  = 0 degrees
    # Desired Pitch = 0 degrees
    # -----------------------------------------

    initial_roll = 10.0
    initial_pitch = 10.0

    # -----------------------------------------
    # 8. CONVERT DEGREES TO RADIANS
    # -----------------------------------------

    initial_roll_radians = (
        initial_roll * math.pi / 180.0
    )

    initial_pitch_radians = (
        initial_pitch * math.pi / 180.0
    )

    # -----------------------------------------
    # 9. CREATE INITIAL QUATERNION
    # -----------------------------------------

    initial_quaternion = p.getQuaternionFromEuler(
        [
            initial_roll_radians,
            initial_pitch_radians,
            0.0
        ]
    )

    # -----------------------------------------
    # 10. APPLY INITIAL ORIENTATION
    # -----------------------------------------

    p.resetBasePositionAndOrientation(
        drone.drone_id,
        [0.0, 0.0, 1.0],
        initial_quaternion
    )

    # -----------------------------------------
    # 11. CALCULATE HOVER THRUST
    # -----------------------------------------

    gravity = 9.81

    hover_thrust = (
        drone.mass * gravity
    )

    # -----------------------------------------
    # 12. PRINT INITIAL CONDITIONS
    # -----------------------------------------

    print("\nInitial roll:", initial_roll)
    print("Initial pitch:", initial_pitch)

    print("\nDesired roll:", desired_roll)
    print("Desired pitch:", desired_pitch)

    print("\nDrone mass:", drone.mass, "kg")
    print("Gravity:", gravity, "m/s^2")
    print("Hover thrust:", hover_thrust, "N")

    # -----------------------------------------
    # 13. START STABILIZATION LOOP
    # -----------------------------------------

    print("\nStabilization loop started...\n")

    print(
        "Time\t"
        "Roll\t"
        "Pitch\t"
        "Roll Error\t"
        "Roll PID\t"
        "Pitch Error\t"
        "Pitch PID"
    )

    # -----------------------------------------
    # 14. CLOSED-LOOP CONTROL
    # -----------------------------------------

    for step in range(1200):

        # -------------------------------------
        # A. READ IMU
        # -------------------------------------

        actual_roll, actual_pitch, actual_yaw = (
            imu.get_orientation()
        )

        # -------------------------------------
        # B. CALCULATE PID CORRECTIONS
        # -------------------------------------

        (
            roll_correction,
            pitch_correction,
            roll_p,
            roll_i,
            roll_d,
            pitch_p,
            pitch_i,
            pitch_d
        ) = controller.calculate_corrections(
            desired_roll,
            actual_roll,
            desired_pitch,
            actual_pitch,
            dt
        )

        # -------------------------------------
        # C. MIX PID OUTPUT INTO 4 MOTORS
        # -------------------------------------

        (
            motor_1,
            motor_2,
            motor_3,
            motor_4
        ) = mixer.calculate_motor_thrust(
            total_thrust=hover_thrust,
            roll_correction=roll_correction,
            pitch_correction=pitch_correction,
            yaw_correction=0.0
        )

        # -------------------------------------
        # D. APPLY MOTOR FORCES
        # -------------------------------------

        drone.apply_motor_forces(
            motor_1,
            motor_2,
            motor_3,
            motor_4
        )

        # -------------------------------------
        # E. ADVANCE PHYSICS
        # -------------------------------------

        physics.step()

        # -------------------------------------
        # F. CALCULATE ERRORS
        # -------------------------------------

        roll_error = (
            desired_roll - actual_roll
        )

        pitch_error = (
            desired_pitch - actual_pitch
        )

        # -------------------------------------
        # G. PRINT EVERY 0.2 SECONDS
        # -------------------------------------

        if step % 48 == 0:

            print(
                f"{step * dt:.2f}\t"
                f"{actual_roll:.2f}\t"
                f"{actual_pitch:.2f}\t"
                f"{roll_error:.2f}\t"
                f"{roll_correction:.2f}\t"
                f"{pitch_error:.2f}\t"
                f"{pitch_correction:.2f}"
            )

    # -----------------------------------------
    # 15. CLOSE PHYSICS
    # -----------------------------------------

    physics.close()

    print("\nStabilization test completed.")


# -----------------------------------------
# PROGRAM START
# -----------------------------------------

if __name__ == "__main__":
    main()