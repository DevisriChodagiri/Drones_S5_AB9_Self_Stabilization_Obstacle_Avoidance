import sys
import os
import math
import pybullet as p

# =========================================================
# PROJECT PATH
# =========================================================

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


# =========================================================
# IMPORT PROJECT MODULES
# =========================================================

from simulation.physics import PhysicsWorld
from simulation.drone import Drone
from control.attitude_controller import AttitudeController
from control.motor_mixer import MotorMixer
from sensors.imu import IMU


# =========================================================
# CREATE WORLD AND DRONE
# =========================================================

world = PhysicsWorld()

drone = Drone()

imu = IMU(drone.drone_id)

attitude_controller = AttitudeController()

mixer = MotorMixer(
    max_thrust=5.0
)


# =========================================================
# SIMULATION SETTINGS
# =========================================================

dt = 1.0 / 240.0

simulation_time = 5.0

desired_roll = 0.0
desired_pitch = 0.0

# Thrust required approximately to balance gravity
hover_thrust = drone.mass * 9.81


# =========================================================
# INITIAL DISTURBANCE
# =========================================================

initial_roll = 10.0
initial_pitch = 8.0

initial_roll_rad = math.radians(initial_roll)
initial_pitch_rad = math.radians(initial_pitch)

initial_orientation = p.getQuaternionFromEuler(
    [
        initial_roll_rad,
        initial_pitch_rad,
        0.0
    ]
)

p.resetBasePositionAndOrientation(
    drone.drone_id,
    [0.0, 0.0, 1.0],
    initial_orientation
)


# =========================================================
# HEADER
# =========================================================

print("\n==============================================")
print("       ROLL + PITCH PID TEST")
print("==============================================")

print("\nInitial Roll :", initial_roll, "degrees")
print("Initial Pitch:", initial_pitch, "degrees")

print("Desired Roll :", desired_roll, "degrees")
print("Desired Pitch:", desired_pitch, "degrees")

print("Hover Thrust :", hover_thrust)

print(
    "\nTime\tRoll\tPitch\t"
    "RErr\tPErr\t"
    "RPID\tPPID\t"
    "M1\tM2\tM3\tM4"
)

print("-" * 100)


# =========================================================
# SIMULATION LOOP
# =========================================================

steps = int(simulation_time / dt)

for step in range(steps):

    time_value = step * dt


    # -----------------------------------------------------
    # READ IMU
    # -----------------------------------------------------

    roll, pitch, yaw = imu.get_orientation()


    # -----------------------------------------------------
    # CALCULATE ROLL + PITCH PID
    # -----------------------------------------------------

    (
        roll_output,
        pitch_output,
        roll_p,
        roll_i,
        roll_d,
        pitch_p,
        pitch_i,
        pitch_d
    ) = attitude_controller.calculate_corrections(
        desired_roll,
        roll,
        desired_pitch,
        pitch,
        dt
    )


    # -----------------------------------------------------
    # CONVERT PID OUTPUT TO THRUST CORRECTION
    # -----------------------------------------------------

    roll_correction = roll_output * 0.05

    pitch_correction = pitch_output * 0.05

    yaw_correction = 0.0


    # -----------------------------------------------------
    # MOTOR MIXING
    # -----------------------------------------------------

    (
        motor_1,
        motor_2,
        motor_3,
        motor_4
    ) = mixer.calculate_motor_thrust(
        hover_thrust,
        roll_correction,
        pitch_correction,
        yaw_correction
    )


    # -----------------------------------------------------
    # APPLY MOTOR FORCES
    # -----------------------------------------------------

    drone.apply_motor_forces(
        motor_1,
        motor_2,
        motor_3,
        motor_4
    )


    # -----------------------------------------------------
    # PRINT RESULTS
    # -----------------------------------------------------

    if step % 24 == 0:

        roll_error = desired_roll - roll
        pitch_error = desired_pitch - pitch

        print(
            f"{time_value:.2f}\t"
            f"{roll:.2f}\t"
            f"{pitch:.2f}\t"
            f"{roll_error:.2f}\t"
            f"{pitch_error:.2f}\t"
            f"{roll_output:.2f}\t"
            f"{pitch_output:.2f}\t"
            f"{motor_1:.2f}\t"
            f"{motor_2:.2f}\t"
            f"{motor_3:.2f}\t"
            f"{motor_4:.2f}"
        )


    # -----------------------------------------------------
    # ADVANCE PHYSICS
    # -----------------------------------------------------

    world.step()


# =========================================================
# CLOSE WORLD
# =========================================================

world.close()

print("\n==============================================")
print("Roll + Pitch PID test completed.")
print("==============================================\n")