import sys
import os

# -----------------------------------------
# ADD PROJECT ROOT TO PYTHON PATH
# -----------------------------------------

sys.path.append(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)

from navigation.obstacle_avoidance import ObstacleAvoidance


def main():

    print("Starting obstacle avoidance test...")

    # -----------------------------------------
    # CREATE OBSTACLE AVOIDANCE SYSTEM
    # -----------------------------------------

    avoidance = ObstacleAvoidance(
        safe_distance=1.5,
        danger_distance=0.8
    )

    # -----------------------------------------
    # TEST DISTANCES
    # -----------------------------------------

    test_distances = [
        3.0,
        2.0,
        1.5,
        1.2,
        1.0,
        0.8,
        0.5
    ]

    print("\nDistance\tStatus")
    print("-------------------------")

    # -----------------------------------------
    # TEST EACH DISTANCE
    # -----------------------------------------

    for distance in test_distances:

        status = avoidance.check_distance(
            distance
        )

        print(
            f"{distance:.2f} m\t\t{status}"
        )

    print(
        "\nObstacle avoidance test completed."
    )


if __name__ == "__main__":
    main()