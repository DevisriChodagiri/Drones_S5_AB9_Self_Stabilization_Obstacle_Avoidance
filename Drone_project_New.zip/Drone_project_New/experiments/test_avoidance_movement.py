import sys
import os

sys.path.append(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)

from navigation.obstacle_avoidance import ObstacleAvoidance


def main():

    print("Starting mathematical avoidance movement test...")

    avoidance = ObstacleAvoidance(
        safe_distance=1.5,
        danger_distance=0.8,
        warning_ttc=5.0,
        danger_ttc=2.0
    )

    # Initial conditions
    distance = 5.0

    # Obstacle closing speed
    closing_speed = 0.5

    dt = 0.1

    drone_speed = 0.08

    print(
        "\nTime\tDistance\tClosing\tTTC\tAction\tDrone Speed"
    )

    print(
        "------------------------------------------------------------"
    )

    for step in range(100):

        time_value = step * dt

        # -----------------------------------------
        # CALCULATE TTC
        # -----------------------------------------

        if closing_speed > 0:

            ttc = distance / closing_speed

        else:

            ttc = float("inf")

        # -----------------------------------------
        # DECISION
        # -----------------------------------------

        action = avoidance.decide_action(
            distance,
            closing_speed,
            ttc
        )

        # -----------------------------------------
        # DRONE RESPONSE
        # -----------------------------------------

        if action == "CONTINUE":

            drone_speed = 0.08

        elif action == "SLOW_DOWN":

            drone_speed = 0.03

        elif action == "AVOID":

            drone_speed = 0.0

        # -----------------------------------------
        # PRINT
        # -----------------------------------------

        if step % 5 == 0:

            if ttc == float("inf"):

                ttc_text = "INF"

            else:

                ttc_text = f"{ttc:.2f}"

            print(
                f"{time_value:.1f}\t"
                f"{distance:.2f}\t\t"
                f"{closing_speed:.2f}\t"
                f"{ttc_text}\t"
                f"{action}\t"
                f"{drone_speed:.2f}"
            )

        # -----------------------------------------
        # UPDATE DISTANCE
        # -----------------------------------------

        distance = distance - closing_speed * dt

        # -----------------------------------------
        # INCREASE OBSTACLE SPEED
        # -----------------------------------------
        # This simulates a dynamic obstacle
        # becoming faster as it approaches.

        closing_speed = closing_speed + 0.05

        # -----------------------------------------
        # STOP IF AVOIDANCE IS REQUIRED
        # -----------------------------------------

        if action == "AVOID":

            print(
                "\nObstacle became dangerous."
            )

            print(
                "Drone stopped forward movement "
                "and entered AVOID mode."
            )

            break

    print(
        "\nMathematical avoidance movement test completed."
    )


if __name__ == "__main__":
    main()