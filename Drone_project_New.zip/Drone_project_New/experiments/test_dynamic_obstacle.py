import sys
import os
import pybullet as p

# -----------------------------------------
# ADD PROJECT ROOT TO PYTHON PATH
# -----------------------------------------

sys.path.append(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)

from simulation.physics import PhysicsWorld
from simulation.drone import Drone
from simulation.environment import Environment
from sensors.distance_sensor import DistanceSensor


def main():

    print("Starting accelerating dynamic obstacle test...")

    # -----------------------------------------
    # 1. CREATE PHYSICS WORLD
    # -----------------------------------------

    physics = PhysicsWorld()

    # -----------------------------------------
    # 2. CREATE DRONE
    # -----------------------------------------

    drone = Drone()

    # -----------------------------------------
    # 3. CREATE ENVIRONMENT
    # -----------------------------------------

    environment = Environment()

    # -----------------------------------------
    # 4. CREATE OBSTACLE
    # -----------------------------------------

    obstacle_position = [5.0, 0.0, 1.0]

    obstacle_id = environment.add_static_obstacle(
        position=obstacle_position,
        size=[0.2, 0.2, 0.2]
    )

    # -----------------------------------------
    # 5. CREATE DISTANCE SENSOR
    # -----------------------------------------

    sensor = DistanceSensor(
        drone_id=drone.drone_id,
        max_distance=10.0
    )

    # -----------------------------------------
    # 6. MOVEMENT PARAMETERS
    # -----------------------------------------

    velocity = -0.5

    acceleration = -0.2

    dt = 0.1

    # -----------------------------------------
    # 7. DISPLAY HEADER
    # -----------------------------------------

    print(
        "\nTime\tPosition\tVelocity\tDistance"
    )

    print(
        "------------------------------------------------"
    )

    # -----------------------------------------
    # 8. MOVE OBSTACLE
    # -----------------------------------------

    for step in range(20):

        time = step * dt

        # -------------------------------------
        # GET CURRENT OBSTACLE POSITION
        # -------------------------------------

        obstacle_position, orientation = (
            p.getBasePositionAndOrientation(
                obstacle_id
            )
        )

        current_x = obstacle_position[0]

        # -------------------------------------
        # UPDATE VELOCITY
        #
        # v_new = v_old + a * dt
        # -------------------------------------

        velocity = velocity + acceleration * dt

        # -------------------------------------
        # UPDATE POSITION
        #
        # x_new = x_old + v * dt
        # -------------------------------------

        new_x = current_x + velocity * dt

        # -------------------------------------
        # UPDATE OBSTACLE POSITION
        # -------------------------------------

        p.resetBasePositionAndOrientation(
            obstacle_id,
            [new_x, 0.0, 1.0],
            orientation
        )

        # -------------------------------------
        # MEASURE DISTANCE
        # -------------------------------------

        distance = sensor.get_distance_to_obstacle(
            obstacle_id
        )

        # -------------------------------------
        # DISPLAY VALUES
        # -------------------------------------

        print(
            f"{time:.1f}\t{new_x:.2f}\t\t"
            f"{velocity:.2f}\t\t{distance:.2f}"
        )

        # -------------------------------------
        # STEP PHYSICS
        # -------------------------------------

        physics.step()

    # -----------------------------------------
    # 9. CLOSE SIMULATION
    # -----------------------------------------

    physics.close()

    print(
        "\nAccelerating dynamic obstacle test "
        "completed."
    )


if __name__ == "__main__":
    main()