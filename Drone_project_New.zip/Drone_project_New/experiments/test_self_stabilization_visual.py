
# ============================================================
# PYBULLET PID SELF-STABILIZATION WITH WIND DISTURBANCE
# ============================================================
#
# Project:
# Autonomous Self-Stabilizing Drone with Intelligent
# Obstacle Avoidance
#
# Experiment:
# PID Disturbance Rejection
#
# The drone:
#   1. Starts slightly tilted
#   2. Stabilizes itself
#   3. Receives artificial wind disturbances
#   4. IMU measures the resulting attitude
#   5. PID calculates correction
#   6. Motor mixer changes motor thrust
#   7. Drone returns toward 0 degree roll/pitch
#
# ============================================================


import sys
import os
import math
import time
import csv

import pybullet as p


# ============================================================
# PROJECT ROOT
# ============================================================

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


# ============================================================
# IMPORT PROJECT MODULES
# ============================================================

from simulation.drone import Drone
from sensors.imu import IMU
from control.pid_controller import PIDController
from control.motor_mixer import MotorMixer


# ============================================================
# WIND DISTURBANCE FUNCTION
# ============================================================

def get_wind_disturbance(current_time):

    """
    Artificial wind disturbance schedule.

    Returns:

        force_x
        force_y
        force_z

        torque_x
        torque_y
        torque_z

        wind_name
    """

    # --------------------------------------------------------
    # 0 - 2 seconds
    # No wind
    # --------------------------------------------------------

    if current_time < 2.0:

        return (
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            "NO WIND"
        )


    # --------------------------------------------------------
    # 2 - 3 seconds
    # Wind from +X
    # --------------------------------------------------------

    if 2.0 <= current_time < 3.0:

        return (
            -1.5,
            0.0,
            0.0,
            0.0,
            0.10,
            0.0,
            "WIND +X"
        )


    # --------------------------------------------------------
    # 3 - 4 seconds
    # Recovery
    # --------------------------------------------------------

    if 3.0 <= current_time < 4.0:

        return (
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            "RECOVERY"
        )


    # --------------------------------------------------------
    # 4 - 5 seconds
    # Wind from -X
    # --------------------------------------------------------

    if 4.0 <= current_time < 5.0:

        return (
            1.5,
            0.0,
            0.0,
            0.0,
            -0.10,
            0.0,
            "WIND -X"
        )


    # --------------------------------------------------------
    # 5 - 6 seconds
    # Recovery
    # --------------------------------------------------------

    if 5.0 <= current_time < 6.0:

        return (
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            "RECOVERY"
        )


    # --------------------------------------------------------
    # 6 - 7 seconds
    # Wind from +Y
    # --------------------------------------------------------

    if 6.0 <= current_time < 7.0:

        return (
            0.0,
            -1.5,
            0.0,
            0.10,
            0.0,
            0.0,
            "WIND +Y"
        )


    # --------------------------------------------------------
    # 7 - 8 seconds
    # Recovery
    # --------------------------------------------------------

    if 7.0 <= current_time < 8.0:

        return (
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            "RECOVERY"
        )


    # --------------------------------------------------------
    # 8 - 9 seconds
    # Wind from -Y
    # --------------------------------------------------------

    if 8.0 <= current_time < 9.0:

        return (
            0.0,
            1.5,
            0.0,
            -0.10,
            0.0,
            0.0,
            "WIND -Y"
        )


    # --------------------------------------------------------
    # 9 - 10 seconds
    # Recovery
    # --------------------------------------------------------

    if 9.0 <= current_time < 10.0:

        return (
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            "RECOVERY"
        )


    # --------------------------------------------------------
    # 10 - 11 seconds
    # Strong diagonal wind
    # --------------------------------------------------------

    if 10.0 <= current_time < 11.0:

        return (
            -2.0,
            -2.0,
            0.0,
            0.15,
            0.15,
            0.0,
            "STRONG DIAGONAL WIND"
        )


    # --------------------------------------------------------
    # 11 seconds onwards
    # Final recovery
    # --------------------------------------------------------

    return (
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        "FINAL RECOVERY"
    )


# ============================================================
# MAIN FUNCTION
# ============================================================

def main():

    print()
    print("=" * 75)
    print("       PYBULLET PID WIND DISTURBANCE TEST")
    print("=" * 75)
    print()


    # ========================================================
    # CONNECT TO PYBULLET GUI
    # ========================================================

    print("Opening PyBullet GUI...")

    client = p.connect(p.GUI)

    if client < 0:

        print(
            "ERROR: Could not connect to PyBullet GUI."
        )

        return

    print(
        "PyBullet GUI connected."
    )

    print(
        "Physics client ID:",
        client
    )

    print()


    # ========================================================
    # PHYSICS SETTINGS
    # ========================================================

    time_step = 1.0 / 240.0

    p.setGravity(
        0,
        0,
        -9.81,
        physicsClientId=client
    )

    p.setTimeStep(
        time_step,
        physicsClientId=client
    )


    # ========================================================
    # GROUND
    # ========================================================

    ground_shape = p.createCollisionShape(
        p.GEOM_PLANE,
        physicsClientId=client
    )

    p.createMultiBody(
        baseMass=0,
        baseCollisionShapeIndex=ground_shape,
        basePosition=[0, 0, 0],
        physicsClientId=client
    )


    # ========================================================
    # CREATE DRONE
    # ========================================================

    drone = Drone()

    print(
        "Drone created."
    )


    # ========================================================
    # CREATE IMU
    # ========================================================

    imu = IMU(
        drone.drone_id
    )


    # ========================================================
    # CREATE ROLL PID
    # ========================================================

    roll_pid = PIDController(
        kp=0.8,
        ki=0.1,
        kd=0.05
    )


    # ========================================================
    # CREATE PITCH PID
    # ========================================================

    pitch_pid = PIDController(
        kp=0.8,
        ki=0.1,
        kd=0.05
    )


    # ========================================================
    # CREATE MOTOR MIXER
    # ========================================================

    mixer = MotorMixer(
        max_thrust=5.0
    )


    # ========================================================
    # DESIRED ATTITUDE
    # ========================================================

    desired_roll = 0.0

    desired_pitch = 0.0


    # ========================================================
    # INITIAL DRONE DISTURBANCE
    # ========================================================

    initial_roll = math.radians(
        5.0
    )

    initial_pitch = math.radians(
        4.0
    )

    initial_yaw = 0.0


    initial_orientation = p.getQuaternionFromEuler(
        [
            initial_roll,
            initial_pitch,
            initial_yaw
        ]
    )


    # ========================================================
    # INITIAL POSITION + ORIENTATION
    # ========================================================

    p.resetBasePositionAndOrientation(
        drone.drone_id,
        [0, 0, 1],
        initial_orientation,
        physicsClientId=client
    )


    # ========================================================
    # INITIAL VELOCITY
    # ========================================================

    p.resetBaseVelocity(
        drone.drone_id,
        linearVelocity=[0, 0, 0],
        angularVelocity=[0, 0, 0],
        physicsClientId=client
    )


    # ========================================================
    # CAMERA
    # ========================================================

    p.resetDebugVisualizerCamera(
        cameraDistance=3.5,
        cameraYaw=45,
        cameraPitch=-25,
        cameraTargetPosition=[
            0,
            0,
            1
        ],
        physicsClientId=client
    )


    # ========================================================
    # WORLD AXES
    # ========================================================

    # X axis

    p.addUserDebugLine(
        [0, 0, 0.02],
        [2, 0, 0.02],
        lineColorRGB=[1, 0, 0],
        lineWidth=2,
        lifeTime=0,
        physicsClientId=client
    )


    # Y axis

    p.addUserDebugLine(
        [0, 0, 0.02],
        [0, 2, 0.02],
        lineColorRGB=[0, 1, 0],
        lineWidth=2,
        lifeTime=0,
        physicsClientId=client
    )


    # Z axis

    p.addUserDebugLine(
        [0, 0, 0],
        [0, 0, 2],
        lineColorRGB=[0, 0, 1],
        lineWidth=2,
        lifeTime=0,
        physicsClientId=client
    )


    # ========================================================
    # HOVER THRUST
    # ========================================================

    mass = drone.mass

    gravity = 9.81

    hover_thrust = (
        mass * gravity
    )

    motor_hover_thrust = (
        hover_thrust / 4.0
    )


    # ========================================================
    # PID CORRECTION SCALE
    # ========================================================

    correction_scale = 0.05


    # ========================================================
    # PID OUTPUT LIMIT
    # ========================================================

    pid_limit = 20.0


    # ========================================================
    # TOTAL SIMULATION TIME
    # ========================================================

    simulation_time = 15.0

    total_steps = int(
        simulation_time / time_step
    )


    # ========================================================
    # RESULTS FOLDER
    # ========================================================

    results_folder = os.path.join(
        PROJECT_ROOT,
        "results"
    )

    os.makedirs(
        results_folder,
        exist_ok=True
    )


    # ========================================================
    # CSV FILE
    # ========================================================

    csv_path = os.path.join(
        results_folder,
        "pid_wind_disturbance.csv"
    )


    csv_file = open(
        csv_path,
        "w",
        newline=""
    )


    csv_writer = csv.writer(
        csv_file
    )


    # ========================================================
    # CSV HEADER
    # ========================================================

    csv_writer.writerow(
        [
            "Time",
            "Wind",
            "WindForceX",
            "WindForceY",
            "WindForceZ",
            "WindTorqueX",
            "WindTorqueY",
            "WindTorqueZ",

            "DesiredRoll",
            "ActualRoll",
            "RollError",
            "RollP",
            "RollI",
            "RollD",
            "RollPID",

            "DesiredPitch",
            "ActualPitch",
            "PitchError",
            "PitchP",
            "PitchI",
            "PitchD",
            "PitchPID",

            "Motor1",
            "Motor2",
            "Motor3",
            "Motor4"
        ]
    )


    # ========================================================
    # PRINT CONFIGURATION
    # ========================================================

    print(
        "INITIAL CONDITION"
    )

    print(
        "Roll  = 5 degrees"
    )

    print(
        "Pitch = 4 degrees"
    )

    print()

    print(
        "DESIRED CONDITION"
    )

    print(
        "Roll  = 0 degrees"
    )

    print(
        "Pitch = 0 degrees"
    )

    print()

    print(
        "PID PARAMETERS"
    )

    print(
        "Kp =",
        roll_pid.kp
    )

    print(
        "Ki =",
        roll_pid.ki
    )

    print(
        "Kd =",
        roll_pid.kd
    )

    print()

    print(
        "HOVER THRUST =",
        hover_thrust,
        "N"
    )

    print(
        "EACH MOTOR =",
        motor_hover_thrust,
        "N"
    )

    print()

    print(
        "WIND SCHEDULE"
    )

    print(
        "2-3 s   : WIND +X"
    )

    print(
        "4-5 s   : WIND -X"
    )

    print(
        "6-7 s   : WIND +Y"
    )

    print(
        "8-9 s   : WIND -Y"
    )

    print(
        "10-11 s : STRONG DIAGONAL WIND"
    )

    print()

    print(
        "Watch the PyBullet window."
    )

    print()


    # ========================================================
    # CONTROL LOOP
    # ========================================================

    simulation_running = True

    last_print_time = 0.0

    previous_wind = ""


    try:

        for step in range(total_steps):


            # =================================================
            # CHECK CONNECTION
            # =================================================

            if not p.isConnected(
                physicsClientId=client
            ):

                print()

                print(
                    "PyBullet GUI was closed/disconnected."
                )

                simulation_running = False

                break


            # =================================================
            # CURRENT TIME
            # =================================================

            current_time = (
                step * time_step
            )


            # =================================================
            # GET WIND
            # =================================================

            (
                wind_fx,
                wind_fy,
                wind_fz,
                wind_tx,
                wind_ty,
                wind_tz,
                wind_name
            ) = get_wind_disturbance(
                current_time
            )


            # =================================================
            # PRINT WIND EVENT
            # =================================================

            if wind_name != previous_wind:

                print()

                print(
                    ">>>",
                    f"{current_time:.2f}s",
                    ":",
                    wind_name
                )

                previous_wind = wind_name


            # =================================================
            # READ IMU
            # =================================================

            (
                actual_roll,
                actual_pitch,
                actual_yaw
            ) = imu.get_orientation()


            # =================================================
            # ROLL PID
            # =================================================

            (
                roll_output,
                roll_p,
                roll_i,
                roll_d
            ) = roll_pid.calculate(
                desired_roll,
                actual_roll,
                time_step
            )


            # =================================================
            # PITCH PID
            # =================================================

            (
                pitch_output,
                pitch_p,
                pitch_i,
                pitch_d
            ) = pitch_pid.calculate(
                desired_pitch,
                actual_pitch,
                time_step
            )


            # =================================================
            # LIMIT ROLL PID
            # =================================================

            if roll_output > pid_limit:

                roll_output = pid_limit


            if roll_output < -pid_limit:

                roll_output = -pid_limit


            # =================================================
            # LIMIT PITCH PID
            # =================================================

            if pitch_output > pid_limit:

                pitch_output = pid_limit


            if pitch_output < -pid_limit:

                pitch_output = -pid_limit


            # =================================================
            # PID → MOTOR CORRECTION
            # =================================================

            roll_correction = (
                roll_output *
                correction_scale
            )

            pitch_correction = (
                pitch_output *
                correction_scale
            )


            # =================================================
            # MOTOR MIXING
            # =================================================

            (
                motor_1,
                motor_2,
                motor_3,
                motor_4
            ) = mixer.calculate_motor_thrust(
                hover_thrust,
                roll_correction,
                pitch_correction,
                0.0
            )


            # =================================================
            # APPLY MOTOR FORCES
            # =================================================

            drone.apply_motor_forces(
                motor_1,
                motor_2,
                motor_3,
                motor_4
            )


            # =================================================
            # APPLY WIND FORCE
            # =================================================

            if (
                wind_fx != 0.0
                or
                wind_fy != 0.0
                or
                wind_fz != 0.0
            ):

                p.applyExternalForce(
                    drone.drone_id,
                    -1,
                    [
                        wind_fx,
                        wind_fy,
                        wind_fz
                    ],
                    [0, 0, 0],
                    p.LINK_FRAME,
                    physicsClientId=client
                )


            # =================================================
            # APPLY WIND TORQUE
            # =================================================

            if (
                wind_tx != 0.0
                or
                wind_ty != 0.0
                or
                wind_tz != 0.0
            ):

                p.applyExternalTorque(
                    drone.drone_id,
                    -1,
                    [
                        wind_tx,
                        wind_ty,
                        wind_tz
                    ],
                    p.LINK_FRAME,
                    physicsClientId=client
                )


            # =================================================
            # STEP PHYSICS
            # =================================================

            p.stepSimulation(
                physicsClientId=client
            )


            # =================================================
            # CALCULATE ERRORS
            # =================================================

            roll_error = (
                desired_roll -
                actual_roll
            )

            pitch_error = (
                desired_pitch -
                actual_pitch
            )


            # =================================================
            # SAVE CSV
            # =================================================

            csv_writer.writerow(
                [
                    current_time,

                    wind_name,

                    wind_fx,
                    wind_fy,
                    wind_fz,

                    wind_tx,
                    wind_ty,
                    wind_tz,

                    desired_roll,
                    actual_roll,
                    roll_error,

                    roll_p,
                    roll_i,
                    roll_d,
                    roll_output,

                    desired_pitch,
                    actual_pitch,
                    pitch_error,

                    pitch_p,
                    pitch_i,
                    pitch_d,
                    pitch_output,

                    motor_1,
                    motor_2,
                    motor_3,
                    motor_4
                ]
            )


            # =================================================
            # TERMINAL DISPLAY
            # =================================================

            if (
                current_time -
                last_print_time
                >= 0.1
            ):

                print(
                    f"{current_time:5.2f}s | "
                    f"{wind_name:23s} | "
                    f"Roll={actual_roll:7.2f}° | "
                    f"Pitch={actual_pitch:7.2f}° | "
                    f"RPID={roll_output:7.2f} | "
                    f"PPID={pitch_output:7.2f}"
                )

                last_print_time = current_time


            # =================================================
            # REAL-TIME DELAY
            # =================================================

            time.sleep(
                time_step
            )


    except KeyboardInterrupt:

        print()

        print(
            "Simulation stopped by user."
        )


    except Exception as error:

        print()

        print(
            "Simulation error:"
        )

        print(
            error
        )


    finally:

        # ====================================================
        # CLOSE CSV
        # ====================================================

        csv_file.close()

        print()

        print(
            "Data saved to:"
        )

        print(
            csv_path
        )


    # ========================================================
    # FINAL RESULT
    # ========================================================

    if (
        simulation_running
        and
        p.isConnected(
            physicsClientId=client
        )
    ):

        final_roll, final_pitch, final_yaw = (
            imu.get_orientation()
        )


        print()
        print("=" * 75)
        print("FINAL PID WIND DISTURBANCE RESULT")
        print("=" * 75)

        print(
            f"Final Roll  : {final_roll:.2f}°"
        )

        print(
            f"Final Pitch : {final_pitch:.2f}°"
        )

        print(
            f"Final Yaw   : {final_yaw:.2f}°"
        )

        print()


        # ====================================================
        # SUCCESS CHECK
        # ====================================================

        if (
            abs(final_roll) < 2.0
            and
            abs(final_pitch) < 2.0
        ):

            print(
                "PID DISTURBANCE REJECTION SUCCESS!"
            )

            print()

            print(
                "The drone returned close to:"
            )

            print(
                "Roll  = 0 degrees"
            )

            print(
                "Pitch = 0 degrees"
            )

        else:

            print(
                "PID requires further tuning."
            )


        print()

        print(
            "Close the PyBullet window when finished."
        )


        # ====================================================
        # KEEP GUI OPEN
        # ====================================================

        while p.isConnected(
            physicsClientId=client
        ):

            time.sleep(0.1)


    # ========================================================
    # DISCONNECT
    # ========================================================

    if p.isConnected(
        physicsClientId=client
    ):

        p.disconnect(
            physicsClientId=client
        )


    print()

    print(
        "PyBullet connection closed."
    )

    print()


# ============================================================
# PROGRAM START
# ============================================================

if __name__ == "__main__":

    main()

