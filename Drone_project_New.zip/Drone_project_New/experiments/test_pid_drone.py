import sys
import os
import math
import pybullet as p


# =========================================================
# PROJECT PATH
# =========================================================

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


# =========================================================
# IMPORT OUR PROJECT MODULES
# =========================================================

from simulation.physics import PhysicsWorld
from simulation.drone import Drone
from control.pid_controller import PIDController
from control.motor_mixer import MotorMixer
from sensors.imu import IMU


# =========================================================
# CREATE PHYSICS WORLD
# =========================================================

world = PhysicsWorld()

drone = Drone()

imu = IMU(drone.drone_id)

pid = PIDController(
    kp=0.8,
    ki=0.1,
    kd=0.05
)

mixer = MotorMixer(
    max_thrust=5.0
)


# =========================================================
# SIMULATION PARAMETERS
# =========================================================

dt = 1.0 / 240.0

simulation_time = 5.0

desired_roll = 0.0

# Total thrust required approximately to balance gravity
hover_thrust = drone.mass * 9.81


# =========================================================
# INITIAL ROLL DISTURBANCE
# =========================================================

initial_roll = 10.0

initial_roll_radians = math.radians(initial_roll)

initial_orientation = p.getQuaternionFromEuler(
    [initial_roll_radians, 0.0, 0.0]
)

p.resetBasePositionAndOrientation(
    drone.drone_id,
    [0.0, 0.0, 1.0],
    initial_orientation
)

print("\n==============================================")
print("       REAL PYBULLET PID TEST")
print("==============================================")

print("\nInitial Roll:", initial_roll, "degrees")
print("Desired Roll:", desired_roll, "degrees")
print("Hover Thrust:", hover_thrust)

print("\nTime\tRoll\tError\tP\tI\tD\tPID\tM1\tM2\tM3\tM4")
print("-" * 110)


# =========================================================
# SIMULATION LOOP
# =========================================================

steps = int(simulation_time / dt)

for step in range(steps):

    time_value = step * dt


    # -----------------------------------------------------
    # READ ROLL FROM IMU
    # -----------------------------------------------------

    roll, pitch, yaw = imu.get_orientation()


    # -----------------------------------------------------
    # CALCULATE PID
    # -----------------------------------------------------

    pid_output, proportional, integral, derivative = (
        pid.calculate(
            desired_roll,
            roll,
            dt
        )
    )


    # -----------------------------------------------------
    # CONVERT PID CORRECTION TO MOTOR THRUST
    # -----------------------------------------------------

    roll_correction = pid_output * 0.05

    pitch_correction = 0.0

    yaw_correction = 0.0


    # -----------------------------------------------------
    # CALCULATE FOUR MOTOR THRUST VALUES
    # -----------------------------------------------------

    motor_1, motor_2, motor_3, motor_4 = (
        mixer.calculate_motor_thrust(
            hover_thrust,
            roll_correction,
            pitch_correction,
            yaw_correction
        )
    )


    # -----------------------------------------------------
    # APPLY MOTOR FORCES
    # -----------------------------------------------------

    drone.apply_motor_forces(
        motor_1,
        motor_2,
        motor_3,
        motor_4
    )


    # -----------------------------------------------------
    # PRINT EVERY 24 STEPS
    # -----------------------------------------------------

    if step % 24 == 0:

        error = desired_roll - roll

        print(
            f"{time_value:.2f}\t"
            f"{roll:.2f}\t"
            f"{error:.2f}\t"
            f"{proportional:.2f}\t"
            f"{integral:.2f}\t"
            f"{derivative:.2f}\t"
            f"{pid_output:.2f}\t"
            f"{motor_1:.2f}\t"
            f"{motor_2:.2f}\t"
            f"{motor_3:.2f}\t"
            f"{motor_4:.2f}"
        )


    # -----------------------------------------------------
    # ADVANCE PHYSICS
    # -----------------------------------------------------

    world.step()


# =========================================================
# CLOSE SIMULATION
# =========================================================

world.close()

print("\n==============================================")
print("Real PyBullet PID test completed.")
print("==============================================\n")