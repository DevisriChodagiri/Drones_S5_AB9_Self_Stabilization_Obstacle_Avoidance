import sys
import os

sys.path.append(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)

from simulation.physics import PhysicsWorld
from simulation.drone import Drone
from sensors.imu import IMU

import pybullet as p


def main():

    print("Starting IMU test...")

    # Create physics world
    physics = PhysicsWorld()

    # Create drone
    drone = Drone()

    # Create simulated IMU
    imu = IMU(drone.drone_id)

    # -----------------------------------------
    # INITIAL ORIENTATION
    # -----------------------------------------

    print("\nInitial orientation:")

    roll, pitch, yaw = imu.get_orientation()

    print("Roll :", roll)
    print("Pitch:", pitch)
    print("Yaw  :", yaw)

    # -----------------------------------------
    # APPLY 10 DEGREE ROLL
    # -----------------------------------------

    angle = 10.0

    angle_radians = (
        angle * 3.141592653589793 / 180.0
    )

    quaternion = p.getQuaternionFromEuler(
        [angle_radians, 0.0, 0.0]
    )

    p.resetBasePositionAndOrientation(
        drone.drone_id,
        [0, 0, 1],
        quaternion
    )

    # -----------------------------------------
    # READ IMU AGAIN
    # -----------------------------------------

    roll, pitch, yaw = imu.get_orientation()

    print("\nAfter applying 10 degree roll:")

    print("Roll :", roll)
    print("Pitch:", pitch)
    print("Yaw  :", yaw)

    physics.close()

    print("\nIMU test completed.")


if __name__ == "__main__":
    main()