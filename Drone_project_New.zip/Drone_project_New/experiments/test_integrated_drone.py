import sys
import os
import pickle
import math
import pandas as pd
import pybullet as p


# ---------------------------------------------------------
# ADD PROJECT ROOT TO PYTHON PATH
# ---------------------------------------------------------

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


# ---------------------------------------------------------
# IMPORT PROJECT MODULES
# ---------------------------------------------------------

from simulation.physics import PhysicsWorld
from simulation.drone import Drone
from navigation.decision_controller import DecisionController


# ---------------------------------------------------------
# DISTANCE CALCULATION
# ---------------------------------------------------------

def calculate_distance(drone_position, obstacle_position):

    dx = obstacle_position[0] - drone_position[0]
    dy = obstacle_position[1] - drone_position[1]
    dz = obstacle_position[2] - drone_position[2]

    distance = math.sqrt(
        dx * dx +
        dy * dy +
        dz * dz
    )

    return distance


# ---------------------------------------------------------
# CLOSING SPEED CALCULATION
# ---------------------------------------------------------

def calculate_closing_speed(
    previous_distance,
    current_distance,
    dt
):

    if dt <= 0:
        return 0.0

    closing_speed = (
        previous_distance - current_distance
    ) / dt

    # If distance is increasing,
    # obstacle is not approaching.
    if closing_speed < 0:
        closing_speed = 0.0

    return closing_speed


# ---------------------------------------------------------
# TIME TO COLLISION
# ---------------------------------------------------------

def calculate_ttc(distance, closing_speed):

    if closing_speed <= 0.01:
        return 20.0

    ttc = distance / closing_speed

    if ttc > 20.0:
        ttc = 20.0

    return ttc


# ---------------------------------------------------------
# LATERAL SEPARATION
# ---------------------------------------------------------

def calculate_lateral_separation(
    drone_position,
    obstacle_position
):

    separation = abs(
        drone_position[1] -
        obstacle_position[1]
    )

    return separation


# ---------------------------------------------------------
# MAIN
# ---------------------------------------------------------

def main():

    print("\n==============================================")
    print(" INTEGRATED DRONE + ML + DYNAMIC OBSTACLE")
    print("==============================================\n")


    # -------------------------------------------------
    # CREATE PHYSICS WORLD
    # -------------------------------------------------

    world = PhysicsWorld()

    drone = Drone()


    # -------------------------------------------------
    # CREATE DYNAMIC OBSTACLE
    # -------------------------------------------------

    obstacle_shape = p.createCollisionShape(
        p.GEOM_BOX,
        halfExtents=[0.3, 0.3, 0.5],
        physicsClientId=world.client
    )

    obstacle_id = p.createMultiBody(
        baseMass=0,
        baseCollisionShapeIndex=obstacle_shape,
        basePosition=[6.0, 0.0, 1.0],
        physicsClientId=world.client
    )


    # -------------------------------------------------
    # LOAD ML MODEL
    # -------------------------------------------------

    model_path = os.path.join(
        PROJECT_ROOT,
        "results",
        "risk_model.pkl"
    )

    scaler_path = os.path.join(
        PROJECT_ROOT,
        "results",
        "scaler.pkl"
    )

    with open(model_path, "rb") as file:
        model = pickle.load(file)

    with open(scaler_path, "rb") as file:
        scaler = pickle.load(file)

    print("ML model loaded successfully.")
    print("Scaler loaded successfully.")


    # -------------------------------------------------
    # DECISION CONTROLLER
    # -------------------------------------------------

    decision_controller = DecisionController()


    # -------------------------------------------------
    # SIMULATION PARAMETERS
    # -------------------------------------------------

    dt = 1.0 / 240.0

    simulation_time = 18.0

    total_steps = int(
        simulation_time / dt
    )

    # Normal forward speed
    continue_speed = 0.08

    # Warning speed
    slow_speed = 0.03

    # Strong lateral avoidance speed
    avoid_sideways_speed = 0.50

    # Dynamic obstacle speed
    obstacle_speed = 0.50

    # Required lateral clearance
    required_clearance = 1.0


    # -------------------------------------------------
    # INITIAL VALUES
    # -------------------------------------------------

    previous_distance = 6.0

    avoidance_active = False

    avoidance_start_time = None

    avoidance_completed = False

    resume_forward = False


    # -------------------------------------------------
    # OUTPUT HEADER
    # -------------------------------------------------

    print(
        "\nTime\tDistance\tClosing\tTTC\t"
        "Risk\tAction\tSpeedX\tSpeedY\t"
        "Drone(X,Y)\tObstacle(X,Y)\tLateral"
    )

    print("-" * 125)


    # -------------------------------------------------
    # SIMULATION LOOP
    # -------------------------------------------------

    for step in range(total_steps):

        time_value = step * dt


        # -------------------------------------------------
        # GET POSITIONS
        # -------------------------------------------------

        drone_position = drone.get_position()

        obstacle_position, obstacle_orientation = (
            p.getBasePositionAndOrientation(
                obstacle_id,
                physicsClientId=world.client
            )
        )


        # -------------------------------------------------
        # DISTANCE
        # -------------------------------------------------

        distance = calculate_distance(
            drone_position,
            obstacle_position
        )


        # -------------------------------------------------
        # CLOSING SPEED
        # -------------------------------------------------

        closing_speed = calculate_closing_speed(
            previous_distance,
            distance,
            dt
        )


        # -------------------------------------------------
        # TTC
        # -------------------------------------------------

        ttc = calculate_ttc(
            distance,
            closing_speed
        )


        # -------------------------------------------------
        # ATTITUDE
        #
        # For this navigation test,
        # we keep roll and pitch at zero.
        #
        # PID stabilization will be integrated later.
        # -------------------------------------------------

        roll = 0.0

        pitch = 0.0


        # -------------------------------------------------
        # PREPARE ML INPUT
        # -------------------------------------------------

        input_data = pd.DataFrame(
            [[
                distance,
                closing_speed,
                ttc,
                roll,
                pitch
            ]],
            columns=[
                "Distance",
                "ClosingSpeed",
                "TTC",
                "Roll",
                "Pitch"
            ]
        )


        # -------------------------------------------------
        # SCALE INPUT
        # -------------------------------------------------

        input_scaled = scaler.transform(
            input_data
        )


        # -------------------------------------------------
        # ML PREDICTION
        # -------------------------------------------------

        risk_prediction = model.predict(
            input_scaled
        )

        risk = risk_prediction[0]


        # -------------------------------------------------
        # DECISION CONTROLLER
        # -------------------------------------------------

        action = decision_controller.decide(
            risk,
            distance,
            closing_speed,
            ttc
        )


        # -------------------------------------------------
        # LATERAL SEPARATION
        # -------------------------------------------------

        lateral_separation = (
            calculate_lateral_separation(
                drone_position,
                obstacle_position
            )
        )


        # -------------------------------------------------
        # MOVEMENT DECISION
        # -------------------------------------------------

        speed_x = 0.0
        speed_y = 0.0


        # =================================================
        # NORMAL FLIGHT
        # =================================================

        if not avoidance_active:

            if action == "CONTINUE":

                speed_x = continue_speed
                speed_y = 0.0


            elif action == "SLOW_DOWN":

                speed_x = slow_speed
                speed_y = 0.0


            elif action == "AVOID":

                avoidance_active = True

                avoidance_start_time = time_value

                print(
                    "\n"
                    "*** DANGER DETECTED ***"
                )

                print(
                    "*** AVOIDANCE MANEUVER STARTED ***"
                )

                print(
                    "Forward movement stopped."
                )

                print(
                    "Drone moving sideways "
                    "to create clearance."
                )

                speed_x = 0.0

                speed_y = avoid_sideways_speed


            else:

                speed_x = 0.0
                speed_y = 0.0


        # =================================================
        # AVOIDANCE MODE
        # =================================================

        else:

            # ---------------------------------------------
            # KEEP FORWARD MOTION STOPPED
            # ---------------------------------------------

            speed_x = 0.0


            # ---------------------------------------------
            # CHECK LATERAL CLEARANCE
            # ---------------------------------------------

            if lateral_separation < required_clearance:

                speed_y = avoid_sideways_speed


            else:

                # -----------------------------------------
                # AVOIDANCE COMPLETED
                # -----------------------------------------

                if not avoidance_completed:

                    avoidance_completed = True

                    print(
                        "\n"
                        "*** OBSTACLE CLEARANCE ACHIEVED ***"
                    )

                    print(
                        f"Lateral separation = "
                        f"{lateral_separation:.2f} m"
                    )

                    print(
                        "*** RESUMING FORWARD FLIGHT ***"
                    )

                    print()


                speed_y = 0.0

                resume_forward = True


        # =================================================
        # RESUME FORWARD FLIGHT
        # =================================================

        if resume_forward:

            speed_x = continue_speed

            speed_y = 0.0


        # -------------------------------------------------
        # APPLY DRONE VELOCITY
        # -------------------------------------------------

        p.resetBaseVelocity(
            drone.drone_id,
            linearVelocity=[
                speed_x,
                speed_y,
                0.0
            ],
            angularVelocity=[
                0.0,
                0.0,
                0.0
            ],
            physicsClientId=world.client
        )


        # -------------------------------------------------
        # MOVE DYNAMIC OBSTACLE
        # -------------------------------------------------

        p.resetBaseVelocity(
            obstacle_id,
            linearVelocity=[
                -obstacle_speed,
                0.0,
                0.0
            ],
            angularVelocity=[
                0.0,
                0.0,
                0.0
            ],
            physicsClientId=world.client
        )


        # -------------------------------------------------
        # PRINT EVERY 24 STEPS
        #
        # 240 physics steps/sec
        # 24 steps = 0.1 sec
        # -------------------------------------------------

        if step % 24 == 0:

            if ttc >= 20.0:

                ttc_text = "20.00"

            else:

                ttc_text = f"{ttc:.2f}"


            print(
                f"{time_value:.2f}\t"
                f"{distance:.2f}\t\t"
                f"{closing_speed:.2f}\t"
                f"{ttc_text}\t"
                f"{risk}\t"
                f"{action}\t"
                f"{speed_x:.2f}\t"
                f"{speed_y:.2f}\t"
                f"D({drone_position[0]:.2f},"
                f"{drone_position[1]:.2f})\t"
                f"O({obstacle_position[0]:.2f},"
                f"{obstacle_position[1]:.2f})\t"
                f"{lateral_separation:.2f}"
            )


        # -------------------------------------------------
        # STORE CURRENT DISTANCE
        # -------------------------------------------------

        previous_distance = distance


        # -------------------------------------------------
        # STEP PHYSICS
        # -------------------------------------------------

        world.step()


    # -------------------------------------------------
    # END SIMULATION
    # -------------------------------------------------

    world.close()

    print(
        "\n=============================================="
    )

    print(
        "Integrated PyBullet ML test completed."
    )

    print(
        "==============================================\n"
    )


# ---------------------------------------------------------
# RUN PROGRAM
# ---------------------------------------------------------

if __name__ == "__main__":

    main()