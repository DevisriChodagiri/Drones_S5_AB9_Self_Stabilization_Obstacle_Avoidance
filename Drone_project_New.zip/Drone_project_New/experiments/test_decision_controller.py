import sys
import os

sys.path.append(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)

from navigation.decision_controller import DecisionController


def main():

    print("Starting decision controller test...")

    controller = DecisionController()

    test_cases = [
        ("SAFE", 5.0, 0.3, 16.67),
        ("WARNING", 3.0, 0.8, 3.75),
        ("DANGER", 1.0, 1.5, 0.67)
    ]

    print(
        "\nRisk\t\tDistance\tClosing\tTTC\tAction"
    )

    print(
        "-------------------------------------------------------"
    )

    for risk, distance, closing_speed, ttc in test_cases:

        action = controller.decide(
            risk,
            distance,
            closing_speed,
            ttc
        )

        print(
            f"{risk}\t\t"
            f"{distance:.2f}\t\t"
            f"{closing_speed:.2f}\t"
            f"{ttc:.2f}\t"
            f"{action}"
        )

    print(
        "\nDecision controller test completed."
    )


if __name__ == "__main__":
    main()