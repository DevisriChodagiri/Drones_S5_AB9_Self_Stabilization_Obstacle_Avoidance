import math
import pybullet as p


class DistanceSensor:

    def __init__(self, drone_id, max_distance=10.0):

        # Store the drone ID
        self.drone_id = drone_id

        # Maximum distance that the sensor can measure
        self.max_distance = max_distance

    def get_drone_position(self):

        position, orientation = (
            p.getBasePositionAndOrientation(
                self.drone_id
            )
        )

        return position

    def get_distance_to_obstacle(
        self,
        obstacle_id
    ):

        # -----------------------------------------
        # 1. GET DRONE POSITION
        # -----------------------------------------

        drone_position = self.get_drone_position()

        drone_x = drone_position[0]
        drone_y = drone_position[1]
        drone_z = drone_position[2]

        # -----------------------------------------
        # 2. GET OBSTACLE POSITION
        # -----------------------------------------

        obstacle_position, obstacle_orientation = (
            p.getBasePositionAndOrientation(
                obstacle_id
            )
        )

        obstacle_x = obstacle_position[0]
        obstacle_y = obstacle_position[1]
        obstacle_z = obstacle_position[2]

        # -----------------------------------------
        # 3. CALCULATE DISTANCE
        # -----------------------------------------

        dx = obstacle_x - drone_x
        dy = obstacle_y - drone_y
        dz = obstacle_z - drone_z

        distance = math.sqrt(
            dx * dx +
            dy * dy +
            dz * dz
        )

        # -----------------------------------------
        # 4. LIMIT SENSOR RANGE
        # -----------------------------------------

        if distance > self.max_distance:
            distance = self.max_distance

        return distance