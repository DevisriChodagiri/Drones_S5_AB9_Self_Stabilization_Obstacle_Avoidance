import math
import pybullet as p


class IMU:

    def __init__(self, drone_id):
        self.drone_id = drone_id

    def get_orientation(self):

        # Get quaternion from the simulated drone
        position, quaternion = p.getBasePositionAndOrientation(
            self.drone_id
        )

        x = quaternion[0]
        y = quaternion[1]
        z = quaternion[2]
        w = quaternion[3]

        # -----------------------------------------
        # QUATERNION → ROLL
        # -----------------------------------------

        roll_numerator = 2.0 * (w * x + y * z)

        roll_denominator = (
            1.0 - 2.0 * (x * x + y * y)
        )

        roll = math.atan2(
            roll_numerator,
            roll_denominator
        )

        # -----------------------------------------
        # QUATERNION → PITCH
        # -----------------------------------------

        pitch_value = 2.0 * (w * y - z * x)

        # Prevent mathematical value from
        # going outside [-1, 1]
        if pitch_value > 1.0:
            pitch_value = 1.0

        if pitch_value < -1.0:
            pitch_value = -1.0

        pitch = math.asin(pitch_value)

        # -----------------------------------------
        # QUATERNION → YAW
        # -----------------------------------------

        yaw_numerator = 2.0 * (w * z + x * y)

        yaw_denominator = (
            1.0 - 2.0 * (y * y + z * z)
        )

        yaw = math.atan2(
            yaw_numerator,
            yaw_denominator
        )

        # -----------------------------------------
        # RADIAN → DEGREE
        # -----------------------------------------

        roll = math.degrees(roll)
        pitch = math.degrees(pitch)
        yaw = math.degrees(yaw)

        return roll, pitch, yaw